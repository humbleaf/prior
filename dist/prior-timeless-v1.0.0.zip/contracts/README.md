# PRIOR Smart Contracts

Complete contract suite for decentralized invention timestamping.

## Contracts

### PRIORTeslaClaim.sol
The core claim contract. Stores content hashes and IPFS CIDs on-chain.

**Address (Base Sepolia):** `0x2405DBaDD194C132713e902d99C8482c771601A4`

**Key Functions:**
- `fileClaim(bytes32 contentHash, string calldata ipfsCID, string calldata assertion)` — File a new Tesla Claim
- `getClaim(uint256 tokenId)` — Retrieve claim details
- `claimsCount()` — Total claims filed

**Events:**
- `ClaimFiled(uint256 indexed tokenId, address indexed claimant, bytes32 contentHash, string ipfsCID, uint256 timestamp)`

---

### TESLARToken.sol
Main ERC-20 token. 1 billion max supply.

**Distribution:**
- 95M (9.5%) — Treasury vesting (4-year linear)
- 50M (5%) — Satoshi lock (9-year, tribute to untouched BTC)
- 855M (85.5%) — Claim mining (earn by filing claims)
- 0% — Team pre-mine (earn through work like everyone else)

**Features:**
- Pausable by governance
- Blacklist for ToS violations
- Mint controlled by PRIORTimelock

---

### MemoryToken.sol
Soulbound subtoken. 100 MEMORY per claim filed.

**Properties:**
- Non-transferable (soulbound)
- 1000:1 conversion to TESLAR (when mechanism active)
- Visual representation of "proof of memory"

---

### PRIORTimelock.sol
Governance timelock. 48-hour delay for normal operations.

**Roles:**
- Proposer: Can queue transactions
- Canceller: Can cancel queued transactions  
- Break-glass: Can execute immediately in emergency (all 3/5 multisig)

**Delays:**
- Normal: 48 hours
- Emergency: 0 hours (requires 3/5 consensus)

---

### TimelockController.sol (Fixed)
OpenZeppelin timelock with H-01 replay protection fix.

**Critical Fix:**
- Added `emergencyExecuted` mapping prevents replay attacks on emergency operations

---

## Deployment Info

**Network:** Base Sepolia (Testnet)  
**Chain ID:** 84532  
**RPC:** https://sepolia.base.org  
**Explorer:** https://sepolia.basescan.org

### Deployed Addresses

| Contract | Address | Status |
|----------|---------|--------|
| PRIORTeslaClaim | 0x2405DBaDD194C132713e902d99C8482c771601A4 | ✅ Live |
| TESLARToken | TBD | ⏳ Pending funding |
| MemoryToken | TBD | ⏳ Pending funding |
| PRIORTimelock | TBD | ⏳ Pending funding |
| TimelockController | TBD | ⏳ Pending funding |

**Deployment Cost:** ~0.003 ETH remaining for full suite

---

## Usage

### Filing a Claim

```javascript
// Using ethers.js
const contract = new ethers.Contract(
  "0x2405DBaDD194C132713e902d99C8482c771601A4",
  PRIORTeslaClaimABI,
  signer
);

// File claim (non-payable, gas only)
const tx = await contract.fileClaim(
  "0x1234...", // SHA-256 hash of content
  "Qm...",     // IPFS CID
  "I invented..." // Your assertion
);

await tx.wait();
```

### Verifying a Claim

```javascript
const claim = await contract.getClaim(tokenId);
// Returns: claimant, contentHash, ipfsCID, timestamp, assertion
```

---

## Verification

### On BaseScan
1. Visit https://sepolia.basescan.org/address/{address}
2. Check "Contract" tab for verified source code
3. Read contract state directly

### IPFS Retrieval
```bash
# Using public gateway
curl https://gateway.pinata.cloud/ipfs/{cid}

# Using local IPFS node
ipfs cat /ipfs/{cid}
```

---

## Security

### Audits
- Pending: OpenZeppelin (recommended by YC)
- Identified: H-01 (replay protection) — FIXED
- M-01–M-05: Medium severity issues accepted as-designed
- L-01–L-07: Low severity issues addressed

### Access Control
- All critical functions behind 48hr timelock
- Emergency break-glass requires 3/5 multisig
- No owner privileges outside timelock

### Trust Assumptions
- Pinata IPFS persistence (1+ year guarantee)
- Base chain finality (L2 settlement on Ethereum)
- Browser Web Crypto API (AES-256-GCM)

---

## License

MIT License — Fork without betrayal. The code belongs to humanity.

---

## The Quiet Invariants

> PRIOR never decides. Only remembers.  
> PRIOR never grants. Only records.  
> PRIOR never revokes. Append-only.  
> Claims are assertions. Not judgments.  
> Memory is permanent. Cannot be unwritten.

These invariants are visible in every contract, every transaction, every page footer.
