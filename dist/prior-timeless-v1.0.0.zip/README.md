# PRIOR — Timeless Package v1.0.0

**The complete, self-contained Prior system.**

This package contains everything needed to file Tesla Claims, verify existence proofs, 
and run the entire Prior application—completely offline, forever.

---

## 🏛️ What's In This Package

### Core Application
- `index.html` — Main PRIOR website (all features, fully functional)
- `_next/` — Static assets (JS, CSS, fonts, images)
- `tesla/` — Tribute to Nikola Tesla
- `manifesto/` — Full philosophical manifesto
- `first-claim/` — Live first claim data

### Tools
- `decrypt.html` — Standalone AES-256-GCM decryption tool
  - Works entirely in browser
  - No internet required
  - Calculates SHA-256 of decrypted content
  - Verify against blockchain record

### Contracts
- `contracts/` — Full Solidity source code
  - PRIORTeslaClaim.sol — Core claim contract
  - TESLARToken.sol — ERC-20 with emission mining
  - MemoryToken.sol — Soulbound subtoken
  - PRIORTimelock.sol — Governance timelock
  - TimelockController.sol — Fixed OZ implementation
  - ABIs for all contracts
  - README with addresses and usage

### Documentation
- `README.md` — This file
- `VERIFICATION.md` — How to verify this package
- `QUIET_INVARIANTS.txt` — Core principles

---

## 🚀 Quick Start

### No Installation Required

1. **Unzip this package**
2. **Double-click `index.html`**
3. **Start filing Tesla Claims immediately**

That's it. No npm install. No server. No build step. It just works.

### Works Offline

- All encryption happens in your browser
- No data sent to any server
- IPFS uploads when connected, or queue for later
- Local-first architecture

---

## 🔐 Verifying Your Claims

### Step 1: Download Encrypted File + Key
When you file a claim, you download:
- `*.prior-encrypted` — Your encrypted file
- `PRIOR-KEY-*.key` — Your decryption key (KEEP THIS SAFE!)

### Step 2: Decrypt Locally
1. Open `decrypt.html` (double-click it)
2. Select your encrypted file
3. Select your key file
4. Click "Decrypt File"
5. Download decrypted content

### Step 3: Verify Hash
The decrypt tool shows the SHA-256 hash of the decrypted content.
Compare this to the blockchain record:

```bash
# View claim on blockchain
https://sepolia.basescan.org/tx/{transaction-hash}

# Or query contract directly
contract.getClaim(tokenId)
# Returns: contentHash, ipfsCID, timestamp, assertion
```

### Step 4: Verify IPFS
```bash
# Using public gateway
curl https://gateway.pinata.cloud/ipfs/{cid}

# Using IPFS CLI
ipfs cat /ipfs/{cid}
```

---

## 📡 Network Configuration

**Current Network:** Base Sepolia (Testnet)

| Parameter | Value |
|-----------|-------|
| Chain ID | 84532 |
| RPC URL | https://sepolia.base.org |
| Explorer | https://sepolia.basescan.org |
| Currency | ETH (testnet) |

**Contract Addresses:**
- PRIORTeslaClaim: `0x2405DBaDD194C132713e902d99C8482c771601A4`
- Others: Pending deployment

**To switch to Mainnet:** Edit `lib/config.ts` in source (requires rebuild)

---

## 🧬 The Quiet Invariants

These principles are embedded in every part of this system:

> **Never decides** → Only remembers  
> **Never grants** → Only records  
> **Never revokes** → Append-only  
> **Claims are assertions** → Not judgments  
> **Memory is permanent** → Cannot be unwritten

PRIOR does not confer legal rights, validate originality, or certify authorship.
It exists so that no idea is ever lost to silence, theft, or time.

---

## 🔬 Technical Stack

| Component | Technology |
|-----------|------------|
| Frontend | Next.js 14 (static export) |
| Encryption | Web Crypto API (AES-256-GCM) |
| Storage | IPFS via Pinata |
| Blockchain | Base L2 (Ethereum L2) |
| Smart Contracts | Solidity + OpenZeppelin |
| Build | Create React App style static export |

---

## 📜 License

**MIT License**

You are free to:
- Use for any purpose
- Modify and distribute
- Fork without permission
- Run your own instance

**This is humanity's tool.** No one owns memory.

---

## 🎯 This Package Is Claim #0

This Timeless Package itself is the **Genesis Tesla Claim**.

When uploaded to IPFS and anchored to the blockchain, it creates a 
**self-referential proof**: the system that timestamps claims, timestamped itself.

**IPFS CID:** [Will be populated after upload]  
**Block Number:** [Will be populated after claim]  
**Transaction:** [Will be populated after confirmation]

This ensures: even if prior-claim.xyz disappears, this package survives.
Anyone can download it, run it locally, and continue filing claims.

---

## 🔗 Links & Resources

- **Live Site:** https://prior-claim.xyz
- **IPFS Gateway:** https://gateway.pinata.cloud
- **Block Explorer:** https://sepolia.basescan.org
- **Tesla Tribute:** /tesla (in this package)
- **Full Manifesto:** /manifesto (in this package)

---

## ⚠️ Important Reminders

1. **Keep your key files safe** — Without them, you cannot decrypt. We cannot help recover them.

2. **This is a testnet deployment** — Costs are minimal (~./build-timeless.sh.001), but so is immutability. Mainnet coming.

3. **Not legal protection** — This creates evidence, not rights. Consult a lawyer for legal advice.

4. **Permanent means permanent** — Once on blockchain and IPFS, it cannot be deleted. Think before you claim.

---

## 🛠️ For Developers

### Building from Source
```bash
# Clone and install
cd prior-app
npm install

# Development server
npm run dev

# Production build (static export)
npm run build

# Output in ./dist/ (configured in next.config.ts)
```

### Contract Deployment
See `contracts/README.md` for full deployment instructions.

---

## 🙏 Acknowledgments

- **Nikola Tesla** — For the vision and the tragedy that inspired this
- **Satoshi Nakamoto** — For proving decentralized consensus works
- **Juan Benet** — For IPFS and content-addressed storage
- **All inventors** — Who've been forgotten. This is for you.

---

**Built with ⚡ by the Prior Team**  
**Timestamped forever on Base**  
**Version 1.0.0 — 2026-02-06T21:31:49Z**

*The future remembers.*
