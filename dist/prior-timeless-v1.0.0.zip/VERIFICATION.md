# Verifying the Timeless Package

## Why Verification Matters

This package claims to be immutable, timestamped, and self-contained.
You should verify this yourself. Trust, but verify.

---

## Step 1: Verify the SHA-256 Hash

This package has a SHA-256 hash recorded on the blockchain.

### Compute Local Hash
\`\`\`bash
# macOS/Linux
shasum -a 256 prior-timeless-v1.0.0.zip

# Windows (PowerShell)
Get-FileHash prior-timeless-v1.0.0.zip -Algorithm SHA256
\`\`\`

### Compare to Blockchain
1. Go to https://sepolia.basescan.org
2. Find Claim #0 transaction
3. Compare the sha256 parameter

They should match exactly.

---

## Step 2: Verify IPFS Retrieval

The package is stored on IPFS with a Content ID.

### Using Public Gateway
\`\`\`bash
curl https://gateway.pinata.cloud/ipfs/{cid} > downloaded.zip
shasum -a 256 downloaded.zip
# Should match original
\`\`\`

### Using IPFS Desktop
1. Install IPFS Desktop from https://docs.ipfs.io/install/ipfs-desktop/
2. Add the CID to your node
3. Verify the content matches

---

## Step 3: Verify Decryption Works

1. Take any .prior-encrypted file from a claim
2. Open decrypt.html from this package
3. Select encrypted file + key
4. Verify successful decryption

---

## Step 4: Verify Contract Interaction

\`\`\`javascript
// Using ethers.js
const provider = new ethers.JsonRpcProvider('https://sepolia.base.org');
const contract = new ethers.Contract(
  '0x2405DBaDD194C132713e902d99C8482c771601A4',
  PRIORTeslaClaimABI,
  provider
);

// Get claim count
const count = await contract.claimsCount();
console.log('Total claims:', count.toString());

// Get specific claim
const claim = await contract.getClaim(0);
console.log('Genesis claim:', claim);
\`\`\`

---

## Red Flags

If any of these fail, the package may be compromised:
- ❌ SHA-256 doesn't match blockchain
- ❌ IPFS returns different content
- ❌ Decryption fails with valid key
- ❌ Contract returns unexpected data

---

## What If The Website Is Down?

This package continues to work even if prior-claim.xyz disappears:

1. Open index.html locally
2. File claims directly to blockchain
3. Upload to IPFS via Pinata (or any IPFS node)
4. Decrypt using decrypt.html

The only thing you lose is the convenience of the hosted UI.
All functionality remains.

---

## What If Pinata Goes Down?

IPFS is distributed. If Pinata's gateway is down:

1. Use ipfs.io gateway: https://ipfs.io/ipfs/{cid}
2. Use Cloudflare: https://cloudflare-ipfs.com/ipfs/{cid}
3. Run your own IPFS node
4. Ask any IPFS user to pin the content

The CID is the key. Any IPFS node can serve it.

---

## What If Base Chain Forks?

Base settles on Ethereum L1. If a major reorganization occurs:

1. Check Ethereum mainnet finality
2. Verify claim in finalized block
3. If still in doubt, re-file the claim

For critical claims, consider multi-chain anchoring (Ethereum, Polygon, etc).

---

## Full Transparency

This package contains:
- ✅ All source code (contracts, frontend)
- ✅ Complete build instructions
- ✅ No minified/hidden code
- ✅ No tracking or analytics
- ✅ No external dependencies for core function

Build it yourself and compare. The hash should match.

---

*Verification is the foundation of trust.*
